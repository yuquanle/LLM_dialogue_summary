from llmtuner import Evaluator


def main():
    evaluator = Evaluator()
    evaluator.eval()


if __name__ == "__main__":
    main()
